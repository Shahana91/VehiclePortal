<?php
include 'connection.php';
$sql = mysqli_query($con, "SELECT * FROM add_transportation_vehicle where vehicle ='bus'	");
$list= array();
if ($sql->num_rows>0){
    while ($row = mysqli_fetch_assoc($sql)){
        $myarray['message'] = 'message';
        $myarray['vehicle'] =$row['vehicle'];
        $myarray['location'] =$row['location'];
        $myarray['price'] =$row['price'];
        $myarray['RC'] =$row['RC'];
        $myarray['insurance'] =$row['insurance'];
        $myarray['dl'] =$row['dl'];
        $myarray['image'] =$row['uploadphoto'];
    array_push($list,$myarray);
    }
}
else{
    $myarray['message']= 'failed';
    array_push($list,$myarray);
}
echo json_encode($list);