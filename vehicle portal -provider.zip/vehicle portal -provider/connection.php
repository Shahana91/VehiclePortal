<?php
$con =mysqli_connect("localhost","root","","vehicles_portal_provider");
?>