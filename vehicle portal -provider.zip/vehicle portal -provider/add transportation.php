<?php
include 'connection.php';
$vehicle=$_POST['vehicle'];
// $seat=$_POST['seat'];
$price=$_POST['price'];
$location=$_POST['location'];
$RC  =$_POST['RC'];
$insurance = $_POST['insurance'];
$dl = $_POST['dl'];

$img=$_FILES['image']['name'];                  
$imagepath='transport/'.$img;
$tmp_name=$_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name,$imagepath);

// // $uploadphoto= $_POST['upload_photo'];
// $sql = mysqli_query($con, "INSERT INTO add_transportation_vehicle(vehicle,seat,price, location)VALUES('$vehicle','$seat','$price','$location')");
// $sql = mysqli_query($con, "INSERT INTO add_transportation_vehicl(vehicle,seat,price,location,RC,insurance,dl,uploadphoto) VALUES ('$vehicle','$seat','$price','$location','$RC','$insurance','$dl','$img')");
$sql = mysqli_query($con, "INSERT INTO add_transportation_vehicle(vehicle,price,location,RC,insurance,dl,uploadphoto) VALUES ('$vehicle','$price','$location','$RC','$insurance','$dl','$img')");

if ($sql)
{
   
    $myarray['message'] = 'added';
 
} else {
    $myarray['message'] = 'failed' . mysqli_error($con);
}
echo json_encode($myarray);
?>